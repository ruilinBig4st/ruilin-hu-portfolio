
# ================================
# Module: CSVParser
# ================================

class CSVParser:
    def parse_field(self, s):
        
        #解析 CSV 中的一个字段。
        #思路：
        #- 如果字段以引号开头，则一直读取到下一个引号
        #- 否则遇到逗号为止
        

         # 若以双引号开头，则读取到下一组引号
        s = s.lstrip()
        if s.startswith('"'):
            s = s[1:]
            end = s.find('"')
            if end == -1:
                raise ValueError("Missing closing quote")
            field = s[:end]
            rest = s[end+1:]
            return field, rest
        # 无引号的常规字段
        chs=""
        i=0
        while i < len(s) and s[i] not in [',','']:
            chs += s[i]
            i += 1
        return chs, s[i:]

    def parse_line(self, line):
   
        #解析一整行，思路：
        #- 不断使用 parse_field 取出字段
        #- 遇到逗号继续，否则跳出
    
        fields=[]
        rest=line
        while rest:
            f,rest = self.parse_field(rest)
            fields.append(f)
               # 若字段后面是逗号，去掉逗号继续解析
            if rest.startswith(","):
                rest=rest[1:]
            else:
                break
        return fields

    def read_csv(self, filename):
        #读取 CSV 文件，输出：
        #- header：（）
        #- table： {col: []}
        with open(filename,'r') as f:
            lines=f.read().splitlines()
        header=lines[0].split(",")
        table={c:[] for c in header}
        for line in lines[1:]:
            vals=self.parse_line(line)
            for c,v in zip(header,vals):
                table[c].append(v)
        return header,table



# ================================
# Module: DataFrame
# ================================

class DataFrame:
    def __init__(self, header, table):
        #header: 列名列表
        #table: {列名: [列数据]} 的字典
        #n: 行数
        self.header=header
        self.table=table
        self.n=len(next(iter(table.values()))) if table else 0

    def __getitem__(self, col):
        #df['BMI']
        return self.table[col]

    def __repr__(self):
        #print(df)
        lines=[' | '.join(self.header)]
        for i in range(min(10,self.n)):
            row=[str(self.table[c][i]) for c in self.header]
            lines.append(' | '.join(row))
        if self.n>10:
            lines.append(f"... ({self.n-10} more rows)")
        return "\n".join(lines)

    def show(self,n=10):
        #展示前 n 行
        print(" | ".join(self.header))
        print("-"* (len(" | ".join(self.header))+3))
        for i in range(min(n,self.n)):
            print(" | ".join(str(self.table[c][i]) for c in self.header))

    def select(self, columns):
        #取出指定列
        new_table={c:self.table[c][:] for c in columns}
        return DataFrame(columns,new_table)

    def where(self, col, op, val):
        #条件过滤：WHERE col op val
        #思路：
        #- 尝试转 float ，否则用字符串比较
        #- 记录满足条件的行号 idx
        idx=[]
        for i,x in enumerate(self.table[col]):
            try:
                xv=float(x); vv=float(val)
            except:
                xv=x; vv=val
            ok=False
            if op=="=": ok=(xv==vv)
            elif op=="!=": ok=(xv!=vv)
            elif op==">": ok=(xv>vv)
            elif op=="<": ok=(xv<vv)
            elif op==">=": ok=(xv>=vv)
            elif op=="<=": ok=(xv<=vv)
            if ok: idx.append(i)
        new_table={c:[self.table[c][i] for i in idx] for c in self.header}
        return DataFrame(self.header,new_table)

    def group_by(self, group_col, agg, agg_col=None):
        #- COUNT：只需要统计行数
        #- SUM / MAX / MIN / AVG：对 agg_col 处理
        groups={}
        for i,k in enumerate(self.table[group_col]):
            groups.setdefault(k,[]).append(i)
        keys=[]; vals=[]
        for k,ids in groups.items():
            keys.append(k)
            if agg == "COUNT":
                vals.append(len(ids))
            else:
                arr=[float(self.table[agg_col][i]) for i in ids]
                if agg=="SUM": vals.append(sum(arr))
                elif agg=="MAX": vals.append(max(arr))
                elif agg=="MIN": vals.append(min(arr))
                elif agg=="AVG": vals.append(sum(arr)/len(arr))
            
         # header name
        if agg_col:
            out_col = f"{agg}({agg_col})"
        else:
            out_col = f"{agg}(*)"

        new_header = [group_col, out_col]
        new_table = {new_header[0]: keys, new_header[1]: vals}

        return DataFrame(new_header, new_table)

    def join(self, other, col_self, col_other, how="inner"):
       #第 1 步：处理右表列名冲突（列名一样时加 _r 后缀）
        # 如果右表一个列名在左表中已经存在，则加 "_r" 避免冲突
        # 如 self.header = ["ID", "Name"], other.header = ["ID", "Value"]
        # 则右表变为 ["ID_r", "Value"]
        right_cols=[]
        for c in other.header:
            right_cols.append(c+"_r" if c in self.header else c)
        # 新表的列名 = 左表所有列 + 处理后的右表所有列
        new_header=self.header+right_cols
         # 使用字典创建新的空表，用于存放 join 结果
        new_table={c:[] for c in new_header}
        # matched 用于标记右表中哪些行被成功匹配过
        matched=set()

    # 第 2 步：遍历左表每一行，在右表寻找匹配行
        for i in range(self.n):
            hit=False
            for j in range(other.n):
                if self.table[col_self][i]==other.table[col_other][j]:
                    hit=True
                    matched.add(j)
                    for c in self.header:
                        new_table[c].append(self.table[c][i])
                    for oc,nc in zip(other.header,right_cols):
                        new_table[nc].append(other.table[oc][j])
        #     if how in ["left","full"] and not hit:
        #         for c in self.header:
        #             new_table[c].append(self.table[c][i])
        #         for nc in right_cols:
        #             new_table[nc].append(None)

        # if how in ["right","full"]:
        #     for j in range(other.n):
        #         if j not in matched:
        #             for c in self.header:
        #                 new_table[c].append(None)
        #             for oc,nc in zip(other.header,right_cols):
        #                 new_table[nc].append(other.table[oc][j])
        return DataFrame(new_header,new_table)



# ================================
# Module: SQLParser
# ================================


class SQLParser:
    def __init__(self, tables):
        """
        tables: a dictionary that maps table names to DataFrame objects.
                Example: {"health": df_health, "sex_info": df_sex}
        """
        self.tables = tables

    def _resolve_column_name(self, df, col):
        """
        Return the actual column name in df.header that matches col
        (case-insensitive). Raises KeyError if not found.
        """
        for real_col in df.header:
            if real_col.lower() == col.lower():
                return real_col
        raise KeyError(col)

    def _strip_quotes(self, val):
        if (val.startswith('"') and val.endswith('"')) or (
            val.startswith("'") and val.endswith("'")
        ):
            return val[1:-1]
        return val

    def _extract_on_condition(self, query_upper, query, on_pos):
        """
        Extract the ON condition substring, stopping before WHERE/GROUP/LIMIT etc.
        """
        rest = query[on_pos + 2 :].strip()
        rest_upper = query_upper[on_pos + 2 :].strip()
        terminators = [" WHERE ", " GROUP BY ", " ORDER BY ", " LIMIT "]
        end = len(rest)
        for term in terminators:
            idx = rest_upper.find(term)
            if idx != -1 and idx < end:
                end = idx
        # strip trailing semicolon if any
        candidate = rest[:end].strip()
        return candidate.rstrip(";").strip()

    def _resolve_alias_column(self, col, df, alias_column_maps):
        """
        Resolve a column reference that may include an alias (alias.col).
        """
        token = col.strip()
        if "." in token:
            alias, col_name = token.split(".", 1)
            alias_lower = alias.lower()
            if alias_lower in alias_column_maps:
                col_map = alias_column_maps[alias_lower]
                resolved = col_map.get(col_name.strip().lower())
                if resolved:
                    return resolved
                raise KeyError(col_name.strip())
        return self._resolve_column_name(df, token)

    def run(self, query):
        """
        Execute a simplified SQL query that supports:
        - SELECT columns
        - FROM table (with optional alias)
        - INNER JOIN ... ON ...
        - WHERE column op value
        This parser normalizes whitespace, extracts keywords,
        and maps operations to DataFrame methods.
        """
        # Remove leading/trailing spaces
        q = query.strip()

        # Normalize multiple spaces into one (e.g., "A   JOIN   B" → "A JOIN B")
        q = " ".join(q.split())
        q_upper = q.upper()

        # =====================================================
        # 1. Parse SELECT clause
        # =====================================================
        select_pos = q_upper.find("SELECT")
        from_pos = q_upper.find("FROM")

        if select_pos == -1 or from_pos == -1:
            raise ValueError("SQL must contain SELECT and FROM clauses.")

        # Extract selected columns as a list
        select_part = q[select_pos + 6 : from_pos].strip()
        select_cols = [c.strip() for c in select_part.split(",")]

        # =====================================================
        # 2. Parse FROM clause (table name + optional alias)
        # =====================================================
        rest = q[from_pos + 4 :].strip()
        tokens = rest.split()

        # First token after FROM = table name
        table1_name = tokens[0]
        df1 = self.tables[table1_name]

        # Optional alias (e.g., FROM health h)
        if len(tokens) > 1 and tokens[1].upper() != "JOIN":
            alias1 = tokens[1]
        else:
            alias1 = table1_name

        # Initial result dataframe = first table
        df = df1

        # Track alias -> column name mapping (case-insensitive lookups)
        alias_column_maps = {}
        base_map = {c.lower(): c for c in df1.header}
        alias_column_maps[table1_name.lower()] = base_map
        alias_column_maps[alias1.lower()] = base_map

        # =====================================================
        # 3. Parse JOIN clause (INNER JOIN only)
        # =====================================================
        if "JOIN" in q_upper:
            join_pos = q_upper.find("JOIN")
            on_pos = q_upper.find("ON")

            # Extract "table2 alias?"
            join_part = q[join_pos + 4 : on_pos].strip().split()
            table2_name = join_part[0]
            alias2 = join_part[1] if len(join_part) > 1 else table2_name

            df2 = self.tables[table2_name]
            # Build alias map
            alias_map = {
                alias1: df1,
                table1_name: df1,
                alias2: df2,
                table2_name: df2,
            }

            # Make alias column maps aware of table2/alias2
            right_map_placeholder = {c.lower(): c for c in df2.header}
            alias_column_maps[table2_name.lower()] = right_map_placeholder
            alias_column_maps[alias2.lower()] = right_map_placeholder

            # ------------------------
            # Parse ON condition
            # ------------------------
            on_cond = self._extract_on_condition(q_upper, q, on_pos)

            if "=" not in on_cond:
                raise ValueError("JOIN requires A.col = B.col")

            left_exp, right_exp = on_cond.split("=")
            left_exp = left_exp.strip()
            right_exp = right_exp.strip()

            aliasL, colL = left_exp.split(".")
            aliasR, colR = right_exp.split(".")

            # select actual tables
            df_left = alias_map[aliasL]
            df_right = alias_map[aliasR]

            colL_resolved = self._resolve_column_name(df_left, colL.strip())
            colR_resolved = self._resolve_column_name(df_right, colR.strip())

            # Prepare alias column maps for the right table (respect join rename rules)
            right_alias_map = {}
            for c in df_right.header:
                new_name = c if c not in df_left.header else c + "_r"
                right_alias_map[c.lower()] = new_name
            alias_column_maps[aliasR.lower()] = right_alias_map
            alias_column_maps[table2_name.lower()] = right_alias_map

            # perform join
            df = df_left.join(df_right, colL_resolved, colR_resolved)

        # =====================================================
        # 5. Parse WHERE clause (if present)
        # =====================================================
        if "WHERE" in q_upper:
            where_pos = q_upper.find("WHERE")
            cond = q[where_pos + 5 :].strip()

            # Supported operators
            ops = ["<=", ">=", "!=", "=", ">", "<"]

            for operator in ops:
                if operator in cond:
                    col, val = cond.split(operator)
                    col = col.strip()
                    val = val.strip()
                    resolved_col = self._resolve_alias_column(
                        col, df, alias_column_maps
                    )
                    df = df.where(resolved_col, operator, self._strip_quotes(val))
                    break

        # =====================================================
        # 6. Projection (SELECT columns)
        # =====================================================
                # ---- Parse GROUP BY ----
        group_col = None
        if "GROUP BY" in q.upper():
            gb_pos = q.upper().find("GROUP BY")
            group_col = q[gb_pos + 8:].strip()

        # ---- Parse Aggregation Functions ----
        # 支持 COUNT(*), COUNT(col), SUM(col), AVG(col), MIN(col), MAX(col)
        agg_funcs = ["COUNT", "SUM", "AVG", "MIN", "MAX"]
        agg = None
        agg_col = None

        for col in select_cols:
            col_up = col.upper()
            for f in agg_funcs:
                if col_up.startswith(f + "("):
                    agg = f
                    inside = col[len(f)+1:-1].strip()  # 取括号内
                    agg_col = inside if inside != "*" else None
                    break

        # ---- Handle GROUP BY & Aggregations ----
        if group_col and agg:
            resolved_group_col = self._resolve_alias_column(
                group_col, df, alias_column_maps
            )
            resolved_agg_col = (
                self._resolve_alias_column(agg_col, df, alias_column_maps)
                if agg_col
                else None
            )
            df = df.group_by(resolved_group_col, agg, resolved_agg_col)
            return df

        # ---- SELECT Projection (no group by) ----
        if select_cols != ["*"]:
            resolved_select_cols = []
            for col in select_cols:
                resolved_select_cols.append(
                    self._resolve_alias_column(col, df, alias_column_maps)
                )
            df = df.select(resolved_select_cols)

        return df

    
