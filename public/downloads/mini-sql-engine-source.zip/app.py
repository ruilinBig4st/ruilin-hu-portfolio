from mini_sql_engine import CSVParser, DataFrame, SQLParser


# 1. Load Data

parser = CSVParser()#读取 CSV 文件，返回header和table
header, table = parser.read_csv("data/heart_disease_health_indicators_BRFSS2015.csv")
health = DataFrame(header, table)#将解析出的内容转成 DataFrame 对象

header2, table2 = parser.read_csv("data/heart.csv")
heart2 = DataFrame(header2, table2)

# Register table
sql = SQLParser({
    "health": health,
    "heart2": heart2
})


#welcome page
print("======================================")
print("   Welcome to Mini SQL Engine!         ")
print("   Type SQL queries to explore data.   ")
print("   Type 'quit' to exit.                ")
print("======================================\n")


# 2. SQL Loop

while True:
    query = input("Enter SQL > ")

    # 若输入为空，继续下一循环，不报错
    if query.strip() == "":
        continue
    
    #exit
    if query.lower().strip() in ["quit", "exit"]:
        print("Bye!")
        break
    
    try:
        result = sql.run(query)
        result.show(10)

    # not found error
    except KeyError as e:
        print(f"Error: Column '{e.args[0]}' not found. Please check column names.")

    # SELECT/WHERE error
    except ValueError as e:
        print(f"Syntax Error: {str(e)}")

    # other error
    except Exception as e:
        print("Error:", e)
