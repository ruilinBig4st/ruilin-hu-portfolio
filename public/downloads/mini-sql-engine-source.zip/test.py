from mini_sql_engine import CSVParser, DataFrame, SQLParser

# -----------------------------
# Load CSV
# -----------------------------
parser = CSVParser()
header, table = parser.read_csv("data/heart_disease_health_indicators_BRFSS2015.csv")
df = DataFrame(header, table)

print(header)

print("==== First 10 Rows ====")
df.show(10)

# -----------------------------
# Projection
# -----------------------------
print("\n==== Select BMI, Age, Sex ====")
df_select = df.select(["BMI", "Age", "Sex"])
df_select.show(5)

# -----------------------------
# Filtering
# -----------------------------
print("\n==== BMI > 30 ====")
df_obese = df.where("BMI", ">", 30)
df_obese.show(5)
print("Rows:", df_obese.n)

# -----------------------------
# Group By
# -----------------------------
print("\n==== GROUP BY Sex COUNT ====")
df_group = df.group_by("Sex", "COUNT")
df_group.show()

# -----------------------------
# Join (small test tables)
# -----------------------------
print("\n==== JOIN TEST ====")
df1 = DataFrame(["ID","Value1"], {"ID":[1,2,3], "Value1":["A","B","C"]})
df2 = DataFrame(["ID","Value2"], {"ID":[1,1,3], "Value2":["X","Y","Z"]})

df_join = df1.join(df2, "ID", "ID", how="inner")
df_join.show()

# 从 health 中自动抽样 BMI 值（避免太大表）
unique_bmi = list(set(df["BMI"]))[:30]  

bmi_class_table = DataFrame(
    ["BMI", "BMIClass"],
    {
        "BMI": unique_bmi,
        "BMIClass": [
            "Obese" if float(v) >= 30 else "Normal"
            for v in unique_bmi
        ]
    }
)
print("\n=== JOIN TEST: Adding BMI Class ===")

df_bmi_join = df.join(bmi_class_table, "BMI", "BMI")
df_bmi_join.select(["BMI", "BMI_r", "BMIClass"]).show(10)



# -----------------------------
# SQL Query Test
# -----------------------------
print("\n==== SQL Query Test ====")
sql = SQLParser({"health": df})
result = sql.run("SELECT BMI, Age FROM health WHERE BMI > 30")
result.show(5)

print("\n=== 2. 统计不同性别的肥胖人数 ===")
result = sql.run("SELECT Sex FROM health WHERE BMI > 30")
result.show()

print("\n=== 3. 查看运动习惯与 BMI 的相关性 ===")
# You can manually group because SQLParser doesn't support GROUP BY yet
group = df.where("PhysActivity", "=", "1").group_by("PhysActivity", "AVG", "BMI")
group.show()

print("\n=== 4. 按年龄段统计心脏疾病比例 ===")
result = df.group_by("Age", "AVG", "HeartDiseaseorAttack")
result.show()

result = sql.run("""
SELECT BMI, Sex, Age, HeartDiseaseorAttack
FROM health
WHERE BMI > 30
LIMIT 10
""")

result.show()


h1, t1 = parser.read_csv("data/heart_disease_health_indicators_BRFSS2015.csv")
h2, t2 = parser.read_csv("data/heart.csv")

df_health = DataFrame(h1, t1)
df_heart = DataFrame(h2, t2)

sql = SQLParser({
    "health": df_health,
    "heart2": df_heart
})

result = sql.run("""
SELECT h.age, h.sex, t.HeartDisease
FROM health h
JOIN heart2 t
ON h.sex = t.sex
LIMIT 10;
""")

result.show()